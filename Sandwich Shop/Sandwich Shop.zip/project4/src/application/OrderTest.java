package application;

/** Junit class to test Order class
 * @author FERRIS HUSSEIN
 */

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class OrderTest {

	/**
	 * testing add() method in Order class
	 */

	@Test
	void testAdd() {
		//fail("Not yet implemented");
		Order order = new Order();
		OrderLine orderline = new OrderLine();
		order.add(orderline);
		assertTrue(!order.getOrderLines().isEmpty());
		
	}

	/**
	 * testing remove() method in Order class
	 */

	@Test
	void testRemove() {
		// fail("Not yet implemented");
		Order order = new Order();
		OrderLine orderline = new OrderLine();
		order.add(orderline);
		order.remove(orderline);
		assertTrue(order.getOrderLines().isEmpty());
	}

	/**
	 * testing getOrderLines() method in Order class
	 */

	@Test
	void testGetOrderLines() {
		// fail("Not yet implemented");
		Order order = new Order();
		OrderLine orderline = new OrderLine();
		order.add(orderline);
		ArrayList<OrderLine> var = order.getOrderLines();
		assertTrue(var.size()==1);
	}

	/**
	 * testing resetOrderLines() method in Order class
	 */

	@Test
	void testResetOrderlines() {
		// fail("Not yet implemented");
		Order order = new Order();
		OrderLine orderline = new OrderLine();
		order.add(orderline);
		order.resetOrderlines();
		assertTrue(order.getOrderLines().isEmpty());
	}

	/**
	 * testing getLineNumber() method in Order class
	 */

	@Test
	void testGetLineNumber() {
		Order order = new Order();
		OrderLine orderline = new OrderLine();
		
		order.add(orderline);
		
		int s = order.getLineNumber();
		assertEquals(s , 1);
	}


}
