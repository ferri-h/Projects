package application;

/**
 * This class is a container class for all orderlines and their corresponding lineNumber
 * @author FERRIS HUSSEIN
 */

import java.util.ArrayList;

public class Order implements Customizable {

	private int lineNumber	;
	private ArrayList<OrderLine> orderlines;

	/**
	 * Order constructor, initializes line number and OrderLine arraylist when declared
	 */

	public Order() {
		lineNumber = 0;
		orderlines= new ArrayList<OrderLine>();
	}

	/**
	 * method to add the customer order to orderlines ArrayList
	 * @param obj order to be added
	 * @return truth value of adding customer order
	 */

	@Override
	public boolean add(Object obj) {
		
		OrderLine order= (OrderLine)obj;
		
		if (orderlines.add(order)) {
			setLineNumber(+ 1);
			return true;	
		}
		
		return false;
	}

	/**
	 * method to remove customer order from orderlines Arraylist
	 * @param obj order to be removed
	 * @return truth value of removing customer order
	 */
	
	@Override
	public boolean remove(Object obj) {
		if(orderlines.remove(obj)) {
			orderlines.remove(obj);
			setLineNumber(- 1);
			return true;
		}
			  
		return false;
	}

	/**
	 * Getter method to retrieve orderlines arraylist
	 * @return arraylist containging customer orders
	 */

	public ArrayList<OrderLine> getOrderLines (){
		return orderlines;
	}

	/**
	 * Method to clear all orderlines
	 */

	public void resetOrderlines() {
		orderlines= new ArrayList<OrderLine>();
		lineNumber = 1;
	}

	/**
	 * method to get lineNumber of order
	 * @return lineNumber of order
	 */

	public int getLineNumber() {
		return lineNumber;
	}

	/**
	 * method to set lineNumber of order
	 * @param lineNumber to be set
	 */

	public void setLineNumber(int lineNumber) {
		this.lineNumber += lineNumber;
	}

}
	
