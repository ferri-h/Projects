package application;

/**
 * Junit class to test OrderLine class
 * @author FERRIS HUSSEIN
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OrderLineTest {

	/**
	 * testing getPrice() method in OrderLine
	 */

	@Test
	void testGetPrice() {
		//fail("Not yet implemented");
		OrderLine orderLine = new OrderLine();
		orderLine.setLine(1, new Chicken());
		assertTrue(orderLine.getPrice()==8.99);
	}

	/**
	 * testing setSandwich() method in OrderLine
	 */

	@Test
	void testSetSandwich() {
		OrderLine orderLine = new OrderLine();
		orderLine.setSandwich(new Fish());
		assertTrue(orderLine.getPrice()==12.99);
	}

	/**
	 * testing getSandwich() method in OrderLine
	 */

	@Test
	void testGetSandwich() {
		OrderLine orderLine = new OrderLine();
		orderLine.setSandwich(new Beef());
		assertTrue(orderLine.getSandwich().price()==10.99);
	}

	/**
	 * testing getLineNumber() method in OrderLine
	 */

	@Test
	void testGetLineNumber() {
		OrderLine orderLine = new OrderLine();
		orderLine.setSandwich(new Beef());
		int s = orderLine.getLineNumber();
		assertEquals(s,1);
	}

	/**
	 * testing setOrderLineNumber() method in OrderLine
	 */

	@Test
	void testSetOrderLineNumber() {
		OrderLine orderLine = new OrderLine();
		orderLine.setSandwich(new Beef());
		orderLine.setOrderLineNumber(5);
		int s = orderLine.getLineNumber();
		assertEquals(s,5);
	}

	/**
	 * testing setLine() method in OrderLine
	 */

	@Test
	void testSetLine() {
		OrderLine orderLine = new OrderLine();
		Fish fish = new Fish();
		int s = orderLine.getLineNumber();
		
		orderLine.setLine(2,fish);
		
		assertTrue( s != orderLine.getLineNumber());
		assertTrue(orderLine.getPrice()== 12.99);
		
	}

}
