package application;

/**
 * This class is a container class for fish object
 * @author FERRIS HUSSEIN
 */

import java.util.ArrayList;

public class Fish extends Sandwich {

	protected String [] fishBase= {"Grilled Snapper","Cilantro","Lime"};

	/**
	 * Constructor to initialize new extras arraylist when object is declared
	 */

	public Fish() {
		extras = new ArrayList<Extra>();
	}


	/**
	 * Method to get price of fish with extras
	 * @return price with extras
	 */

	@Override
	public double price() {

		return 12.99+(extras.size()*1.99);
	}

	/**
	 * Method to get base ingredients of fish
	 * @return String representation of base ingredients
	 */

	public String getFishIngredients() {

		String toBereturn="";
		for (int i =0;i<fishBase.length;i++) {
			toBereturn += fishBase[i]+", ";
		}
		return toBereturn;
	}

	/**
	 * method to get all extra ingredients of fish
	 * @return String represntation of all extra ingredients
	 */

	public String getIngredients() {

		String var="";

		for(int i =0; i < extras.size();i++)
			var = var + extras.get(i).toString()+",";

		return 	var;
	}

	/**
	 * toString() method to return String representation of Fish object
	 * @return String representation of chicken object
	 */

	@Override
	public String toString() {
		String output="";

		output= "Fish Sandwich ".concat(getFishIngredients() + getIngredients());

		return output;
	}



}
