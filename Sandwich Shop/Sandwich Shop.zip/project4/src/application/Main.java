package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.fxml.FXMLLoader;

/**
 * Main Class to initialize GUI using Main.fxml
 * Set title
 * Sets window size
 * @author FERRIS HUSSEIN
 */

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("Main.fxml"));
			Scene scene = new Scene(root,660,725);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("Welcome to the Sandwich Shop");
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	 }
	
	public static void main(String[] args) {
		launch(args);
	}
}
