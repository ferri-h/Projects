package application;

/**
 * Junit class to test Fish class
 * @author FERRIS HUSSEIN
 */

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FishTest {

	/**
	 * testing price() method in Fish class
	 */

	@Test
	void testPrice() {
		Fish Fish1 = new Fish();
		Fish Fish2 = new Fish();
		assertEquals(Fish1.price() , Fish2.price(), 8.99);
	}

	/**
	 * testing getIngredients() method in Fish class
	 */


	@Test
	void testGetIngredients() {
		Fish Fish = new Fish();
		Fish.add("Mayo");		
				String  s = Fish.getIngredients();
					assertEquals(s,"Mayo,");
	}

	/**
	 * testing getFishIngredients() method in Fish class
	 */

	@Test
	void testGetFishIngredients() {
		Fish Fish = new Fish();			
		String  s = Fish.getFishIngredients();	
			
	assertEquals(s,"Grilled Snapper, Cilantro, Lime, ");
	}

	/**
	 * testing toString() method in Fish class
	 */

	@Test
	void testToString() {
		Fish Fish = new Fish();
		
		String  s = Fish.toString();
			
		assertEquals(s,"Fish Sandwich Grilled Snapper, Cilantro, Lime, ");
		
	}

}
