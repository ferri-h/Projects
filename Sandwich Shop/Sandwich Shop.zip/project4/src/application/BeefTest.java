package application;

/**
 * Junit class to test beef class
 * @author FERRIS HUSSEIN
 */

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.Assert;

import org.junit.jupiter.api.Test;

class BeefTest {

	/**
	 * testing price() method in beef class
	 */

	@Test
	void testPrice() {
		
		Beef beef1 = new Beef();
		Beef beef2 = new Beef();
		assertEquals(beef1.price() , beef2.price(), 10.99);
		
	}

	/**
	 * testing getBaseIngredients() method in beef class
	 */

	@Test
	void testGetBaseIngredients() {
		
		Beef beef1 = new Beef();
		
		String  s = beef1.getBaseIngredients();
			
			assertEquals(s,"Roast Beef, Provolone Cheese, Mustard, ");
			
		
	}

	/**
	 * test toString() method in beef class
	 */

	@Test
	void testToString() {
		Beef beef1 = new Beef();
		
		String  s = beef1.toString();
			
			assertEquals(s,"Beef Sandwich Roast Beef, Provolone Cheese, Mustard, ");
		
	}

	/**
	 * testing add() method in beef class
	 */

	@Test
	void testAddString() {
		
		Beef beef1 = new Beef();
		beef1.add("Mayo");
		assertFalse(beef1.extras.isEmpty());
	}

}
