package application;

/**
 * This class is a container class for chicken object
 * @author FERRIS HUSSEIN
 */

import java.util.ArrayList;

public class Chicken extends Sandwich {
	
	protected String [] chickenbaseIngredients= {"Fried Chicken","Spicy Sauce","Pickles"};

	/**
	 * Constructor to initialize new extras arraylist when object is declared
	 */

	public Chicken() {
       extras = new ArrayList<Extra>();
	}

	/**
	 * Method to get price of chicken with extras
	 * @return price with extras
	 */

	@Override
	public double price() {
		return 8.99+(extras.size()*1.99);
	}

	/**
	 * Method to get base ingredients of chicken
	 * @return String representation of base ingredients
	 */

	public String getchickenIngredients() {

		String toBereturn="";
		for (int i =0;i<chickenbaseIngredients.length;i++) {
			toBereturn += chickenbaseIngredients[i]+", ";
		}
		return toBereturn;
	}

	/**
	 * method to get all extra ingredients of chicken
	 * @return String represntation of all extra ingredients
	 */

	public String getIngredients() {
		String var="";

		for(int i =0; i < extras.size();i++)
			var = var + extras.get(i).toString()+",";

		return 	var;	//extras.get(1).toString();
	}

	/**
	 * toString() method to return String representation of Chicken object
	 * @return String representation of chicken object
	 */

	public String toString() {
		String output="";
		output= "Chicken Sandwich ".concat(getchickenIngredients() + getIngredients());
		return output;
	}




}
