package application;

import java.util.ArrayList;

/**
 * This class is a container class for beef object
 * @author FERRIS HUSSEIN
 */

public class Beef extends Sandwich{

	protected String [] beefbaseIngredients= {"Roast Beef","Provolone Cheese","Mustard"};

	/**
	 * Constructor to initialize new extras arraylist when object is declared
	 */

	public Beef(){
		extras = new ArrayList<Extra>();
	}

	/**
	 * Method to get price of beef with extras
	 * @return price of sandwich
	 */

	@Override
	public double price() {

		return 10.99+(extras.size()*1.99);
	}

	/**
	 * Method to get base ingredients of beef
	 * @return String representation of base ingredients of beef
	 */

	public String getBaseIngredients() {

		String toBereturn="";
		for (String s: beefbaseIngredients) {
			toBereturn += s+", ";
		}
		return toBereturn;

	}

	/**
	 * Method to get all extra ingredients
	 * @return String representation of all extra ingredients
	 */

	public String getIngredients() {

		String var="";

		for(int i =0; i < extras.size();i++)
			var = var + extras.get(i).toString()+",";

		return 	var;	//extras.get(1).toString();


	}

	/**
	 * toString() method to get String representation of Beef object
	 * @return String representation of beef
	 */

	@Override
	public String toString() {

		String output="";

		output= "Beef Sandwich ".concat(getBaseIngredients()).concat(getIngredients());

		return output;
	}


}
