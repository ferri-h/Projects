package application;

/**
 * Junit class to test chicken class
 * @author FERRIS HUSSEIN
 */

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ChickenTest {

	/**
	 * testing price() method in chicken class
	 */

	@Test
	void testPrice() {
		
		Chicken Chicken1 = new Chicken();
		Chicken Chicken2 = new Chicken();
		assertEquals(Chicken2.price() , Chicken2.price(), 8.99);
	}

	/**
	 * testing getIngredients() method in chicken class
	 */

	@Test
	void testGetIngredients() {
		
		Chicken Chicken1 = new Chicken();
		Chicken1.add("Mayo");		
				String  s = Chicken1.getIngredients();
					assertEquals(s,"Mayo,");
					
				
	}

	/**
	 * testing getchickenIngredients method in chicken class
	 */

	@Test
	void testGetchickenIngredients() {
		
		Chicken Chicken1 = new Chicken();			
				String  s = Chicken1.getchickenIngredients();	
					
			assertEquals(s,"Fried Chicken, Spicy Sauce, Pickles, ");
	}

	/**
	 * testing toString method in chicken class
	 */

	@Test
	void testToString() {
		Chicken Chicken = new Chicken();
		
		String  s = Chicken.toString();
			
			assertEquals(s,"Chicken Sandwich Fried Chicken, Spicy Sauce, Pickles, ");
		
	}

}
