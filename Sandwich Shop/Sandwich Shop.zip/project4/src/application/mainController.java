package application;

/**
 * Main Controller class for order management. Handles add, remove, and clear order.
 * Opens second.fxml
 * @author FERRIS HUSSEIN
 */

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


import java.net.URL;
import java.util.ResourceBundle;


public class mainController implements Initializable{

	/**
	 * Initialize secondController variable
	 */

	secondController second = new secondController();

	/**
	 * Declare sandwich types
	 */

	Chicken chickenVar;
	Beef beefVar ;
	Fish fishVar ;

	/**
	 * Initialize new Order, linenumber, and OrderLine
	 */

	Order myOrder = new Order();
	int linenumber=1;
	OrderLine actualOrder= new OrderLine();
	String choosen="";

	/**
	 * Declare imageView
	 */

	@FXML
	private ImageView imageView;

	/**
	 * Declare ComboBox
	 */

	@FXML
	private ComboBox<String> sandwichComboBox;

	/**
	 * Declare Buttons
	 */

	@FXML
	private Button addIngredientbutton, viewOrderButton, addToOrderButton,clearListbutton,removeIngredientButton;

	/**
	 * Declare ListView of basic ingredients
	 */

	@FXML
	private ListView<String> basicsIngredientsList = new ListView<String>(),infoArea ;

	/**
	 * Declare listiview of all ingredients and listiview of selected ingredients
	 */

	@FXML
	private ListView<String> ingredients =new ListView<String>() , selectedIngredients =new ListView<String>();

	/**
	 * Declare textfield for order total
	 */

	@FXML
	private TextField orderTotal;

	/**
	 * load images
	 */

	@FXML
	private Image chikenImage = new Image("ChickenSandwich.jpg");
	private Image beefImage = new Image("roastbeefsandwich.jpg");
	private Image fishImage = new Image("GrilledFishSandwiche.jpg");

	/**
	 * Declare all Observable Lists
	 */

	ObservableList<String> chikenBasicIngredientslist = FXCollections.observableArrayList("Fried Chicken","Spicy Sauce","Pickles");
	ObservableList<String> beefBasicIngredientslist = FXCollections.observableArrayList("Roast Beef","Provolone Cheese","Mustard");
	ObservableList<String> fishBasicIngredientslist = FXCollections.observableArrayList("Grilled Snapper","Cilantro","Lime");
	ObservableList<String> availableIngredientslist = FXCollections.observableArrayList("Mushrooms","Onions", "Ketchup","Peppers","Jalapenos","Oregano","Pickles","Tuna","Chipotle Sauce","Cheese");
	ObservableList<String> selected;

	/**
	 * Method to add user order to myOrder. Gets selected items.
	 * @param event 'Add to Order' button is clicked
	 */

	@FXML
	void onAddToOrder(ActionEvent event) {

		if (second.isEmpty() && linenumber!= 1 && myOrder.getOrderLines().isEmpty())
			linenumber =1;

		if(choosen.equalsIgnoreCase("chicken")) {
			chickenVar = new Chicken();
			selected = selectedIngredients.getItems();
			for(String s: selected)
				chickenVar.add(s);

			actualOrder.setLine(linenumber,chickenVar);
			myOrder.add(actualOrder);

			//infoArea.appendText(chickenVar+" Price:$"+chickenVar.price()+"\n");
			infoArea.getItems().add("Sandwich added. \n");


		}
		if(choosen.equalsIgnoreCase("beef")) {
			beefVar = new Beef();

			selected = selectedIngredients.getItems();

			for(String s: selected)
				beefVar.add(s);

			actualOrder.setLine(linenumber,beefVar);
			myOrder.add(actualOrder);
			infoArea.getItems().add("Sandwich added. \n");

		}
		if(choosen.equalsIgnoreCase("fish")) {

			fishVar = new Fish();

			selected = selectedIngredients.getItems();


			for(String s: selected)
				fishVar.add(s);

			actualOrder.setLine(linenumber,fishVar);
			myOrder.add(actualOrder);
			infoArea.getItems().add("Sandwich added. \n");
		}
		linenumber++;
		actualOrder = new OrderLine();

	}

	/**
	 * Method to add ingredients to unique order. Gets selected items
	 * @param event 'Add >>' button is clicked
	 */

	@FXML
	void addIngredient(ActionEvent event) {

		if (ingredients.getSelectionModel().getSelectedItems().size()+selectedIngredients.getItems().size()>6 ) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Maximum ingredients");
			alert.setHeaderText("Can't add more than 6 extra ingredients!");
			alert.showAndWait();

		}

		else {

			for ( String s :ingredients.getSelectionModel().getSelectedItems() ) {
				if (!selectedIngredients.getItems().contains(s)) {
					selectedIngredients.getItems().add(s);
				}
			}
			int s;
			s=selectedIngredients.getItems().size();
			orderTotal.setText(String.valueOf(actualOrder.getPrice()+(1.99*s)));
		}

	}

	/**
	 * Method to clear ingredient list
	 * @param event 'Clear list' button is clicked
	 */

	@FXML
	void clearTheList(ActionEvent event) {
		selectedIngredients.getItems().clear();
		orderTotal.setText(String.valueOf(actualOrder.getPrice()));
	}

	/**
	 * Method to remove ingredients to unique order. Gets selected items
	 * @param event '<< Remove' button is clicked
	 */

	@FXML
	void removeIngredient(ActionEvent event) {

		int s;
		selectedIngredients.getItems().removeAll(selectedIngredients.getSelectionModel().getSelectedItems());
		s=selectedIngredients.getItems().size();
		orderTotal.setText(String.valueOf(actualOrder.getPrice()+(1.99*s)));
	}

	/**
	 * Method to check selected sandwich type ands set basic ingredients
	 * @param event sandwich selected from ComboBox
	 */

	@FXML
	void Selectsandwitch(ActionEvent event) {

		if(sandwichComboBox.getSelectionModel().getSelectedItem().equalsIgnoreCase("beef")) {
			imageView.setImage(beefImage);
			basicsIngredientsList.setItems(beefBasicIngredientslist);
			choosen="beef";
			beefVar = new Beef();
			actualOrder.setSandwich(beefVar);
			orderTotal.setText(String.valueOf(actualOrder.getPrice()));

		}

		else if(sandwichComboBox.getSelectionModel().getSelectedItem().equalsIgnoreCase("fish")) {
			imageView.setImage(fishImage);
			basicsIngredientsList.setItems(fishBasicIngredientslist);
			choosen="fish";
			fishVar = new Fish();
			actualOrder.setSandwich(fishVar);
			orderTotal.setText(String.valueOf(actualOrder.getPrice()));


		}
		else {

			imageView.setImage(chikenImage);
			basicsIngredientsList.setItems(chikenBasicIngredientslist);
			choosen="chicken";
			chickenVar = new Chicken();
			actualOrder.setSandwich(chickenVar);
			orderTotal.setText(String.valueOf(actualOrder.getPrice()));


		}
		if (second.isEmpty() && linenumber!= 1 && myOrder.getOrderLines().isEmpty())
			linenumber =1;

	}

	/**
	 * Method to open second stage to view order
	 * @param event 'View Order' button is clicked
	 */

	@FXML
	void selectSecondStage(ActionEvent event) {

		try {
			FXMLLoader loadMe = new FXMLLoader(getClass().getResource("second.fxml"));
			Parent root = (Parent) loadMe.load();
			second = loadMe.getController();
			second.setMyList(myOrder);

			Stage secondStage = new Stage();
			secondStage.setTitle("View Order");
			secondStage.setScene(new Scene(root, 900, 700));
			secondStage.show();


		} catch (Exception e) {
			//System.out.println("error");
			e.printStackTrace();
		}

		if (second.isEmpty() && linenumber!= 1 && myOrder.getOrderLines().isEmpty())
			linenumber =1;

		infoArea.getItems().clear();



	}

	/**
	 * Method to update myOrder
	 * @param order to be set to myOrder
	 */

	void setMyOrder(Order order) {
		myOrder = order;
	}

	/**
	 * method to initialize and set preset items
	 * @param arg0
	 * @param arg1
	 */

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		ObservableList<String> list = FXCollections.observableArrayList("Chicken","Beef","Fish");
		sandwichComboBox.setItems(list);
		basicsIngredientsList.getItems().addAll("Fried Chicken","Spicy Sauce","Pickles");
		ingredients.setItems(availableIngredientslist);
		ingredients.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		selectedIngredients.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		choosen="chicken";
		orderTotal.setText(String.valueOf(actualOrder.getPrice()));
	}

}
