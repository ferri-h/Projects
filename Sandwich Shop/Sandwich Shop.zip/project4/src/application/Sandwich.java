package application;

/**
 * This class is a container class for sandwich object
 * @author FERRIS HUSSEIN
 */

import java.util.ArrayList;

public abstract class Sandwich implements Customizable {
	
	static final int MAX_EXTRA=6;
	static final double PER_EXTRA =1.99; 
	protected ArrayList<Extra> extras;
	
	public abstract double price () ;

	/**
	 * method to add to extras arraylist
	 * @param obj to be added
	 * @return truth value of adding
	 */

	@Override
	public boolean add (Object obj) {
		extras.add(new Extra ((String) obj));
		return true;
	}

	/**
	 * method to remove
	 * @param obj to remove
	 * @return truth value of removing
	 */

	@Override
	public boolean remove(Object obj){
		return true;
	}

	/**
	 * method to get all extra ingredients
	 * @return String representation of all ingredients
	 */

	public String getIngredients() {
		
		String var="";
		
		for(int i =0; i < extras.size();i++)
			var = var + extras.get(i).toString()+", ";
		
		return 	var;

		
	}

}
