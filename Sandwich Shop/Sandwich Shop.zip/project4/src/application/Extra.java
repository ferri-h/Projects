package application;

/**
 * This class is a container class for Extra object
 * @author FERRIS HUSSEIN
 */

public class Extra {
	
	private String extraName ;

	/**
	 * Construct for Extra 'ingredient'
	 * @param theName to set name
	 */

	public Extra(String theName) {
		extraName = theName;
	}

	/**
	 * method to set name of extra ingredient
	 * @param theName to set name
	 */

	public void setExtra(String theName) {
		extraName = theName;
	}

	/**
	 * method to get Extra 'ingredient' name
	 * @return String representation of extra ingredient
	 */

	public String toString() {
		return extraName;
	}
}
