package application;

/**
 * Junit class to test Extra
 * @author FERRIS HUSSEIN
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ExtraTest {

	/**
	 * testing Extra declaration
	 */

	@Test
	void testExtra() {
		Chicken chicken = new Chicken();
		Extra item = new Extra("Onions");
		assertEquals(item.toString(),"Onions");
		
	}

	/**
	 * testing setExtra() method in Extra object
	 */

	@Test
	void testSetExtra() {
		Extra item = new Extra("Empanadas");
		item.setExtra("Oregano");
		assertTrue(item.toString().equals("Oregano"));
	}

	/**
	 * testing toString() method in Extra object
	 */

	@Test
	void testToString() {
		Extra item = new Extra("Ranch");
		assertTrue(item.toString().equals("Ranch"));

	}

}
