package application;

/**
 * Second Controller class for to display second.fxml. View order and includes functions to clear list, remove order, add same order
 * and export order
 * @author FERRIS HUSSEIN
 */

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class secondController implements Initializable{

    /**
     * Initialize new Order()
     */

    Order myOrder = new Order();

    /**
     * Initialize new OrderLine listview
     */

    @FXML
    private ListView<OrderLine> myList = new ListView<OrderLine>();

    /**
     * declare buttons
     */

    @FXML
    private Button sameOrder, removeOrder, clearOrder, back;

    /**
     * declare textfield
     */

    @FXML
    private TextField totalText;

    /**
     * method to set myList
     * @param order to be added to myList
     */

    void setMyList(Order order) {
        myList.getItems().clear();
        myOrder = order;
        for (int i = 0; i < myOrder.getOrderLines().size(); i++) {
            myList.getItems().add(myOrder.getOrderLines().get(i));
        }
        orderTotal();
    }

    /**
     * method to clear myList and myOrder in mainController and secondController
     * @param event "Clear Order' button is clicked
     * @throws IOException on failed fxml load
     */

    @FXML
    public void clearMe(ActionEvent event) throws IOException {
        myList.getItems().clear();
        myOrder.resetOrderlines();

        FXMLLoader loadMe = new FXMLLoader(getClass().getResource("Main.fxml"));
        Parent root = (Parent) loadMe.load();
        mainController main = loadMe.getController();
        
        main.myOrder = new Order();
        myList.refresh();
    }

    /**
     * Method to hide second window
     * @param event 'Back' button is clicked
     */

    @FXML
    public void goBack(ActionEvent event) {
        back.getScene().getWindow().hide();
    }

    /**
     * Method to calculate ordertotal and set textfield 'totalText' value
     */

    @FXML
    public void orderTotal() {
        double total = 0;

        for (int i = 0; i < myOrder.getOrderLines().size(); i++) {
            total += myOrder.getOrderLines().get(i).getPrice();
        }
        totalText.setText(String.valueOf(String.format("%.2f",total)));
    }

    /**
     * method to add same selected order line
     * @param event '+ Same Order Line' button is selected
     * @throws IOException
     */

    @FXML
    public void addSameOrder(ActionEvent event) throws IOException {
        if (myList.getSelectionModel().getSelectedItems().size() == 0) {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("NO SANDWICH SELECTED");
            alert.setHeaderText("Please Select a Sandwich");
            alert.showAndWait();
            return;
        }

        FXMLLoader loadMe = new FXMLLoader(getClass().getResource("Main.fxml"));
        Parent root = (Parent) loadMe.load();
        mainController main = loadMe.getController();

        ObservableList<OrderLine> selected = myList.getSelectionModel().getSelectedItems();

        for (OrderLine i: selected) {
            OrderLine tmp = new OrderLine(i);
            tmp.setOrderLineNumber(myOrder.getOrderLines().get(myOrder.getOrderLines().size()-1).getLineNumber() + 1);
            myOrder.add(tmp);
        }
        main.setMyOrder(myOrder);

        myList.getItems().clear();
        for (int i = 0; i < myOrder.getOrderLines().size(); i++) {
            myList.getItems().add(myOrder.getOrderLines().get(i));
            orderTotal();
        }
    }

    /**
     * method to remove selected order line
     * @param event '- Remove Order Line' button is selected
     * @throws IOException
     */

    @FXML
    public void removeOrderLine(ActionEvent event) throws IOException {
        if (myList.getSelectionModel().getSelectedItems().size() == 0) {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("NO SANDWICH SELECTED");
            alert.setHeaderText("PLEASE SELECT A SANDWICH OR GO BACK");
            alert.showAndWait();
            return;
        }

        FXMLLoader loadMe = new FXMLLoader(getClass().getResource("Main.fxml"));
        Parent root = (Parent) loadMe.load();
        mainController main = loadMe.getController();

        ObservableList<OrderLine> selected = myList.getSelectionModel().getSelectedItems();

        for (OrderLine i: selected) {
            i.setOrderLineNumber(1);
            myOrder.remove(i);
            main.setMyOrder(myOrder);
            //setMyList(myOrder);

            orderTotal();
        }
        setMyList(myOrder);
        System.out.println(myOrder.getOrderLines().size());

    }

    /**
     * Method to export order to file
     * @param event 'Export' button is clicked
     */

    @FXML
    public void exportFile(ActionEvent event) {
        FileChooser fileLoader = new FileChooser();
        fileLoader.setTitle("Save File");
        fileLoader.getExtensionFilters().add(new FileChooser.ExtensionFilter("TXT FILES","*.txt"));
        fileLoader.getExtensionFilters().add(new FileChooser.ExtensionFilter("ALL FILES","*.*"));
        File myFile = fileLoader.showSaveDialog(new Stage());

        try {
            FileWriter writer = new FileWriter(myFile);
            for (OrderLine line: myOrder.getOrderLines()) {
                writer.write(String.valueOf(line) + "\n");
            }
            writer.close();
        } catch (Exception e) {
            // save file not created
        }
    }

    /**
     * checks if myList is empty
     * @return truth value of whether myList is empty
     */
    
    boolean isEmpty() {
		return myList.getItems().isEmpty();
	}

    /**
     * method to intiialize second stage. Allowed multiple selections
     * @param url
     * @param resourceBundle
     */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        myList.getSelectionModel().setSelectionMode((SelectionMode.MULTIPLE));
    }



}