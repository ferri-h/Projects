package application;

/**
 * This class is a container class for each OrderLine
 * @author FERRIS HUSSEIN
 */

public class OrderLine {
	
	private int lineNumber;
	private Sandwich sandwich;
	private double price;

	/**
	 * Contructor to initialize Orderline
	 */

	public OrderLine() {
		lineNumber=1;
		sandwich = new Chicken();
		price = sandwich.price();
	}

	/**
	 * Sets orderline values
	 * @param line to be set
	 */

	public OrderLine(OrderLine line) {
		this.lineNumber = line.lineNumber;
		this.sandwich = line.sandwich;
		this.price = line.price;
	}

	/**
	 * toString() method to return String representation of OrderLine
	 * @return String representation of OrderLine
	 */

	@Override
	public String toString() {
		String output="";
		output= lineNumber+" "+sandwich.toString()+"Price $"+price;
		return output;
	}

	/**
	 * method to get unique sandwich price
	 * @return sandwich price
	 */
	
	public double getPrice() {
		return sandwich.price();
	}

	/**
	 * extra method to set sandwich type
	 * @param aSandwich type to be set
	 */

	public void setSandwich (Sandwich aSandwich) {
		sandwich = aSandwich;
	}

	/**
	 * method to get sandwich type
	 * @return sandwich type
	 */

	public Sandwich getSandwich() {
		return sandwich;
	}

	/**
	 * method to get lineNumber of OrderLine
	 * @return linenumber of OrderLine
	 */

	public int getLineNumber() {
		return lineNumber;
	}

	/**
	 * extra method to set lineNumber of OrderLine
	 * @param num number to be set to lineNumber
	 */

	public void setOrderLineNumber(int num) {
		lineNumber = num;
	}

	/**
	 * method to set both line number and sandwich type
	 * @param serialNumber to set lineNumber
	 * @param aSandwich to set sandwich type
	 */

	public void setLine(int serialNumber, Sandwich aSandwich) {
		lineNumber = serialNumber;
		sandwich =aSandwich;
		price = aSandwich.price();
	}
	
	
	


}
