package application;

/**
 * Interface class for add, remove
 * @author FERRIS HUSSEIN
 */

public interface Customizable {
	
	boolean	add(Object obj) ;
	boolean remove(Object obj);
	

}
