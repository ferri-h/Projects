package com.example.project5;

/**
 * This class is handles all activity in the first screen
 * @author FERRIS HUSSEIN
 */

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    /**
     * Define EditText fields
      */

    private EditText museum1, museum2, museum3, museum4;

    /**
     * Define intent
     */

    Intent intent ;

    /**
     * method to set title, assign EditText values, and assign new Intent to ticketActivity.class
     * @param savedInstanceState a restorable state
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle(getString(R.string.title1));

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        museum1 = findViewById(R.id.museum1);
        museum2 = findViewById(R.id.museum2);
        museum3 = findViewById(R.id.museum3);
        museum4 = findViewById(R.id.museum4);
        intent = new Intent(this, ticketActivity.class);
    }

    /**
     * display ticketActivity given museum1
     * @param view to view activity
     */

    public void gotomuseum1(View view) {
        intent.putExtra("key", 1);
        startActivity(intent);
    }

    /**
     * display ticketActivity given museum2
     * @param view to view activity
     */

    public void gotomuseum2(View view) {
        intent.putExtra("key", 2);
        startActivity(intent);
    }

    /**
     * display ticketActivity given museum3
     * @param view to view activity
     */

    public void gotomuseum3(View view) {
        intent.putExtra("key", 3);
        startActivity(intent);
    }

    /**
     * display ticketActivity given museum4
     * @param view to view activity
     */

    public void gotomuseum4(View view) {
        intent.putExtra("key", 4);
        startActivity(intent);
    }


}
