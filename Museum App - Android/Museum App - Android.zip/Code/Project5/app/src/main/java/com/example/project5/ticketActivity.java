package com.example.project5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.Intent;
import android.content.res.TypedArray;
import android.icu.text.DecimalFormat;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


/**
 * This class is handles all activity in the second screen and calculates ticket cost, sales tax, and total price
 * @author FERRIS HUSSEIN
 */

public class ticketActivity extends AppCompatActivity {

    /**
     * Define ImageView variable
     */

    private ImageView museumImage;

    /**
     * Define TextView variable
     */

    private TextView museumName;

    /**
     * Define spinner variables
     */

    private Spinner spinner1;
    private Spinner spinner2;
    private Spinner spinner3;

    /**
     * Define EditText variables
     */

    private EditText ticketPrice;
    private EditText salesTax;
    private EditText totalPrice;

    /**
     * Define TextView variables
     */

    private TextView adult;
    private TextView senior;
    private TextView students;

    /**
     * Define button variable to calculate costs
     */

    private Button calculate;

    /**
     * variable for key value
     */
    int  value;

    /**
     * Method to create display and perform backend operation of activity screen
     * @param savedInstanceState a restorable state
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // sets title of second screem
        setTitle(getString(R.string.title2));

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket2);

        // Declare toast message
        Toast t = Toast.makeText(getApplicationContext(),getString(R.string.toast_message), Toast.LENGTH_LONG);
        // Display toast message
        t.show();

        // gets museum image by id
        museumImage = findViewById(R.id.imageView);
        // gets museum name by id
        museumName = findViewById(R.id.museumname);

        // gets adult, senior, and students textview fields by id
        adult = findViewById(R.id.adult);
        senior = findViewById(R.id.senior);
        students = findViewById(R.id.students);

        // Sets spin array to array-string is strings.xml
        String[] spin = getResources().getStringArray(R.array.myspin);
        // gets spinner by id
        spinner1 = findViewById(R.id.spinner01);
        spinner2 = findViewById(R.id.spinner02);
        spinner3 = findViewById(R.id.spinner03);

        // gets ticketPrice, salesTax, and totalPrice by id
        ticketPrice = findViewById(R.id.price);
        salesTax = findViewById(R.id.tax);
        totalPrice = findViewById(R.id.total);

        // disable EditText fields so user does not edit
        ticketPrice.setFocusable(false);
        salesTax.setFocusable(false);
        totalPrice.setFocusable(false);

        // declar adapter to attach spin array values to spinners
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,spin);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);
        spinner2.setAdapter(adapter);
        spinner3.setAdapter(adapter);

        // gets calculate button by id
        calculate = findViewById(R.id.calc_button);

        // gets key values
        Bundle extras = getIntent().getExtras();
        // checkif intent extras is not null
        if (extras != null) {
             value = extras.getInt("key");
            //The key argument here must match that used in the other activity
        }

        if( value == 1) { // key value for museum 1
            museumImage.setImageResource(R.drawable.newjerseystatemuseum);
            museumName.setText(getString(R.string.new_jersey_museums));
            adult.setText(getString(R.string.adult_1));
            senior.setText(getString(R.string.senior_1));
            students.setText(getString(R.string.students_1));
        }
        else if (value == 2) { // key value for museum 2
            museumImage.setImageResource(R.drawable.monclairmuseum);
            museumName.setText(getString(R.string.monclair_art_museum));
            adult.setText(getString(R.string.adult_2));
            senior.setText(getString(R.string.senior_2));
            students.setText(getString(R.string.students_2));
        }
        else if (value == 3) { // key value for museum 3
            museumImage.setImageResource(R.drawable.morrismuseum);
            museumName.setText(getString(R.string.morris_museum));
            adult.setText(getString(R.string.adult_3));
            senior.setText(getString(R.string.senior_3));
            students.setText(getString(R.string.students_3));
        }
        else { // key value for museum 4
            museumImage.setImageResource(R.drawable.libertyhallmuseum);
            museumName.setText(getString(R.string.liberty_hall_museum));
            adult.setText(getString(R.string.adult_3));
            senior.setText(getString(R.string.senior_3));
            students.setText(getString(R.string.students_3));
        }

        /**
         * imageView click listener to open webpage for respective museum upon click
         */

        museumImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (value == 1 ) {
                    Intent openPage = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.m1link)));
                    startActivity(openPage);
                } else if (value == 2) {
                    Intent openPage = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.m2link)));
                    startActivity(openPage);
                } else if (value == 3) {
                    Intent openPage = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.m3link)));
                    startActivity(openPage);
                } else if (value == 4) {
                    Intent openPage = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.m4link)));
                    startActivity(openPage);
                }
            }
        });

        /**
         * calculate button click listener to calculate ticket price, sales tax, and total price rounded to two decimal places
         */
        
        calculate.setOnClickListener(new View.OnClickListener() {
            double ticketP = 0;
            double sTax = 0;
            double totalP = 0;

            @Override
            public void onClick(View v) {
                int s1 = Integer.parseInt(spinner1.getSelectedItem().toString());
                int s2 = Integer.parseInt(spinner2.getSelectedItem().toString());
                int s3 = Integer.parseInt(spinner3.getSelectedItem().toString());

                if (value == 1 ) {
                   ticketP = s1 * 7 + s2 * 6 + s3 * 6;
                   sTax = ticketP * 0.06625;
                   totalP = ticketP + sTax;
                } else if (value == 2) {
                    ticketP = s1 * 15 + s2 * 12 + s3 * 12;
                    sTax = ticketP * 0.06625;
                    totalP = ticketP + sTax;
                } else if (value == 3) {
                    ticketP = s1 * 12 + s2 * 8 + s3 * 8;
                    sTax = ticketP * 0.06625;
                    totalP = ticketP + sTax;
                } else if (value == 4) {
                    ticketP = s1 * 12 + s2 * 8 + s3 * 8;
                    sTax = ticketP * 0.06625;
                    totalP = ticketP + sTax;
                }

                ticketPrice.setText(String.format(getResources().getString(R.string.ticket_price),ticketP));
                salesTax.setText(String.format(getResources().getString(R.string.sales_tax),sTax));
                totalPrice.setText(String.format(getResources().getString(R.string.total_price),totalP));

            }
        });

    }
}