package sample;

import java.io.File;
import java.text.DecimalFormat;

/**
 * Stores account types in database, searches for account in database, add account to database, removes account from database, print by last name and by date
 * @author FERRIS HUSSEIN
 */

public class AccountDatabase {
	private Account[] accounts;
	private int size;
	
	/**
	 * This method initiates the account database as an array of size 5
	 */

	public AccountDatabase() {
		accounts = new Account[5];
		size = 0;
	}
	
	/**
	 * This method searches the account database array for a specified account and returns the index if the account is found, -1 otherwise
	 * @param account, account to find in database
	 * @return index of account location in database, -1 otherwise
	 */
	
	private int find(Account account) {
		for (int i = 0; i < size; i++) {
			if (accounts[i].equals(account)) {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * This method is a helper account to 'debit' specified value from balance
	 * Primarily used for Checking and Savings account
	 * @param account, account that withdrawal will occur
	 * @param val, value to be withdrawn
	 * @return truth value of whether withdrawal was successful or not
	 */
	
	public boolean debitHelp(Account account, Double val) {
		for (int i = 0; i < size; i++) {
			if (accounts[i].equals(account)) {
				if (accounts[i].getBalance()- val >0) {
					accounts[i].debit(val);
					return true;
				} 	
			} 
		}
		return false;
	}
	
	/**
	 * If database array is full, extend array size by 5
	 */

	private void grow() {
		
        Account[] extendedAccount = new Account[size + 5];

        for (int i = 0; i < size; i++)
            extendedAccount[i] = accounts[i];

        accounts = extendedAccount;

	}

	/**
	 * Add account to account database array
	 * @param account, account to be added
	 * @return truth value if account was successfully added
	 */
	
	public boolean add(Account account) {
		if (size % 5 == 0)	// checks if bag array is full
            grow();

		int i = find(account); // invokes find method to see if account exists
		
		if (i == -1) {
			accounts[size] = account;
	        size += 1;
	        return true;
		} else {
			return false;
		}	
	} 

	/**
	 * Remove account to account database array
	 * @param account, account to be removed
	 * @return truth value if account was successfully removed
	 */
	
	public boolean remove(Account account) {
		boolean isRemoved = false;
        int index = find(account); // invokes find method to see if account exists
        if (index >= 0) {	
            accounts[index] = accounts[size - 1];
            accounts[size - 1] = null;
            isRemoved = true;
            size -= 1;
        }
        return isRemoved;
	} 
	
	/**
	 * Deposit money to specified account
	 * @param account, account where money will be deposited
	 * @param amount, value to be deposited
	 * @return truth value if deposit was successful or not
	 */

	public boolean deposit(Account account, double amount) {
		int i = find(account); // invokes find method to see if account exists
		
		if (i != -1) 
		{
			accounts[i].credit(amount);
			return true;
		}
		return false;
	}

	/**
	 * Withdraw money of specified account, use primarily for money market accounts
	 * @param account, account where money will be withdrawn
	 * @param amount, value to be withdrawn
	 * @return return 0: withdrawal successful, 1: insufficient funds, -1 account doesn�t exist
	 */

	public int withdrawal(Account account, double amount) { 
		int i = find(account); // invokes find method to see if account exists
		
		if (i == -1) {return -1;}
		
		if ( (accounts[i].getBalance() - amount > 0) ){
			accounts[i].debit(amount);
			((MoneyMarket) accounts[i]).setWith();
			return 0; // successful
		} else { 
			return 1; // insufficient
		}
	}

	/**
	 * Sorts account database by date in ascending order
	 */
	
	private void sortByDateOpen() {
		for (int i = 0; i < accounts.length-1 && accounts[i] != null; i++) {
			for (int j = i+1; j < accounts.length && accounts[j] != null; j++) {
				if (accounts[i].getDate().compareTo(accounts[j].getDate()) > 0) {
					Account tmp = accounts[i];
					accounts[i] = accounts[j];
					accounts[j] = tmp;
				}
			}
		}
	} 

	/**
	 * Sorts account database by last name
	 */
	
	private void sortByLastName() {	
		// sorts by last name
		for (int i = 0; i < accounts.length-1 && accounts[i] != null; i++) {
			for (int j = i+1; j < accounts.length && accounts[j] != null; j++) {
				if (accounts[i].getLastName().compareTo(accounts[j].getLastName()) > 0) {
					Account tmp = accounts[i];
					accounts[i] = accounts[j];
					accounts[j] = tmp;
				}
			}
		}
	}

	/**
	 * Returns String of sorted accounts by date opened in ascending order to be appended to ouput
	 * @return String format of accounts by date opened
	 */

	public String printByDateOpen() {
		if (accounts[0] == null) { // Check if database is empty
			return "Database is empty.\n";
		}
		
		sortByDateOpen();
		DecimalFormat d = new DecimalFormat("'$' ###,###,##0.00"); // format dollar amount

		String retMe = "";

		retMe = retMe.concat("\n--Printing statements by date opened--\n");
		for (int i = 0; i < accounts.length && accounts[i] != null; i++) {
			retMe = retMe.concat("\n");
			
			if (accounts[i].getClass() == Checking.class) {retMe = retMe.concat("*Checking*"); }
			if (accounts[i].getClass() == Savings.class) {retMe = retMe.concat("*Savings*");}
			if (accounts[i].getClass() == MoneyMarket.class) {retMe = retMe.concat("*MoneyMarket*");}
			retMe = retMe.concat(accounts[i].toString());
			if ( accounts[i] instanceof Checking &&((Checking) accounts[i]).getDirect() == true) { // check if direct is true
				retMe = retMe.concat("*direct deposit account*");
			}
			if ( accounts[i] instanceof Savings && ((Savings) accounts[i]).getLoyal() == true) { // check if direct is true
				retMe = retMe.concat("*special Savings account*");
			}
			if ( accounts[i] instanceof MoneyMarket && ((MoneyMarket) accounts[i]).getWith() >= 0) { // check if direct is true
				if (((MoneyMarket) accounts[i]).getWith() == 1) {
					retMe = retMe.concat("*"+((MoneyMarket) accounts[i]).getWith()+" withdrawal*"); // one withdrawal print statement
				} else {
					retMe = retMe.concat("*"+((MoneyMarket) accounts[i]).getWith()+" withdrawals*"); // multiple withdrawal print statement
				}		
			}
			retMe = retMe.concat("\n");
			
			retMe = retMe.concat("-interest: " + d.format(accounts[i].monthlyInterest()) + "\n");
			retMe = retMe.concat("-fee: " + d.format(accounts[i].monthlyFee()) + "\n");
			accounts[i].setBalance(accounts[i].getBalance() - accounts[i].monthlyFee() + accounts[i].monthlyInterest());
			retMe = retMe.concat("-new balance: " + d.format(accounts[i].getBalance()) + "\n");
			
			
		}
		retMe = retMe.concat("--end of printing--\n");
		return retMe;
	}

	/**
	 * Returns String of sorted accounts by last name to be appended to ouput
	 * @return String format of accounts by last name
	 */
	
	public String printByLastName() {
		
		if (accounts[0] == null) { // Check if database is empty
			return "Database is empty.\n";
		}
		
		sortByLastName();
		DecimalFormat d = new DecimalFormat("'$' ###,###,##0.00"); // format dollar amount

		String retMe = "";

		retMe = retMe.concat("\n--Printing statements by last name--\n");
		for (int i = 0; i < accounts.length && accounts[i] != null; i++) {
			retMe = retMe.concat("\n");
			
			if (accounts[i].getClass() == Checking.class) {retMe = retMe.concat("*Checking*"); }
			if (accounts[i].getClass() == Savings.class) {retMe = retMe.concat("*Savings*");}
			if (accounts[i].getClass() == MoneyMarket.class) {retMe = retMe.concat("*MoneyMarket*");}
			retMe = retMe.concat(accounts[i].toString());
			if ( accounts[i] instanceof Checking &&((Checking) accounts[i]).getDirect() == true) { // check if direct is true
				retMe = retMe.concat("*direct deposit account*");
			}
			if ( accounts[i] instanceof Savings && ((Savings) accounts[i]).getLoyal() == true) { // check if direct is true
				retMe = retMe.concat("*special Savings account*");
			}
			if ( accounts[i] instanceof MoneyMarket && ((MoneyMarket) accounts[i]).getWith() >= 0) { // check if direct is true
				if (((MoneyMarket) accounts[i]).getWith() == 1) {
					retMe = retMe.concat("*"+((MoneyMarket) accounts[i]).getWith()+" withdrawal*"); // one withdrawal print statement
				} else {
					retMe = retMe.concat("*"+((MoneyMarket) accounts[i]).getWith()+" withdrawals*"); // multiple withdrawal print statement
				}	
			}
			retMe = retMe.concat("\n");
	
			retMe = retMe.concat("-interest: " + d.format(accounts[i].monthlyInterest()) + "\n");
			retMe = retMe.concat("-fee: " + d.format(accounts[i].monthlyFee()) + "\n");
			accounts[i].setBalance(accounts[i].getBalance() - accounts[i].monthlyFee() + accounts[i].monthlyInterest());
			retMe = retMe.concat("-new balance: " + d.format(accounts[i].getBalance()) + "\n");
			
		}
		retMe = retMe.concat("--end of printing--\n");
		return retMe;
		
	}

	/**
	 * Returns String of all accounts in database to be appended to ouput
	 * @return String format of all acounts in database
	 */


	public String printAccounts() {

		if (accounts[0] == null) { // Check if database is empty
			return "Database is empty.\n";
		}

		String retMe = "";

		retMe = retMe.concat("--Listing accounts in the database--\n");
		for (int i = 0; i < accounts.length && accounts[i] != null; i++) {
			if (accounts[i].getClass() == Checking.class) { retMe = retMe.concat("*Checking*"); }
			if (accounts[i].getClass() == Savings.class) {retMe = retMe.concat("*Savings*");}
			if (accounts[i].getClass() == MoneyMarket.class) {retMe = retMe.concat("*MoneyMarket*");}
			
			retMe = retMe.concat(accounts[i].toString());
			if ( accounts[i] instanceof Checking &&((Checking) accounts[i]).getDirect() == true) { // check if direct is true
				retMe = retMe.concat("*direct deposit account*");
			}
			if ( accounts[i] instanceof Savings && ((Savings) accounts[i]).getLoyal() == true) { // check if isloyal is true
				retMe = retMe.concat("*special Savings account*");
			}
			if ( accounts[i] instanceof MoneyMarket && ((MoneyMarket) accounts[i]).getWith() >= 0) { 
				if (((MoneyMarket) accounts[i]).getWith() == 1) {
					retMe = retMe.concat("*"+((MoneyMarket) accounts[i]).getWith()+" withdrawal*"); // one withdrawal print statement
				} else {
					retMe = retMe.concat("*"+((MoneyMarket) accounts[i]).getWith()+" withdrawals*"); // multiple withdrawal print statement
				}	
			}
			retMe = retMe.concat("\n");
		}
		retMe = retMe.concat("--end of listing--\n");

		return retMe;
	}

	/**
	 * Receives line from input txt file and adds account to database
	 * @param line, String representation of account to be added from import file
	 */

	public void importFileAccounts(String line) {
		String[] lineProcessor = line.split(",");
		String command, fname, lname, balance, date, unique;

		command = lineProcessor[0];
		fname = lineProcessor[1];
		lname = lineProcessor[2];
		balance = lineProcessor[3];
		date = lineProcessor[4];
		unique = lineProcessor[5];

		if (command.equals("C")) {
			Checking newCheck = new Checking();
			newCheck.setHolder(fname,lname);
			newCheck.setBalance(Double.parseDouble(balance));
			newCheck.setDate(date);
			newCheck.setDirect(Boolean.parseBoolean(unique));
			add(newCheck);
		} else if (command.equals("S")) {
			Savings newSave = new Savings();
			newSave.setHolder(fname, lname);
			newSave.setBalance(Double.parseDouble(balance));
			newSave.setDate(date);
			newSave.setLoyal(Boolean.parseBoolean(unique));
			add(newSave);
		} else if (command.equals("M")) {
			MoneyMarket newMM = new MoneyMarket();
			newMM.setHolder(fname, lname);
			newMM.setBalance(Double.parseDouble(balance));
			newMM.setDate(date);
			newMM.setWithVal(Integer.parseInt(unique));
			add(newMM);
		}
	}

	/**
	 * This method is called to return a String representation of accounts to appended to export file
	 * @return String representation of accounts in database to be written in export file
	 */

	public String exportFileAccounts() {
		String retMe = "";

		for (int i = 0; i < accounts.length && accounts[i] != null; i++) {
			if (accounts[i].getClass() == Checking.class) { retMe = retMe.concat("C,"); }
			if (accounts[i].getClass() == Savings.class) {retMe = retMe.concat("S,");}
			if (accounts[i].getClass() == MoneyMarket.class) {retMe = retMe.concat("M,");}

			retMe = retMe.concat(accounts[i].getFirstName() + "," + accounts[i].getLastName() + "," + accounts[i].getBalance() + "," + accounts[i].getDate().toString() + ",");

			if ( accounts[i] instanceof Checking &&((Checking) accounts[i]).getDirect() == true) { // check if direct is true
				retMe = retMe.concat("true\n");
			} else if (accounts[i] instanceof Checking &&((Checking) accounts[i]).getDirect() == false) {
				retMe = retMe.concat("false\n");
			}

			if ( accounts[i] instanceof Savings && ((Savings) accounts[i]).getLoyal() == true) { // check if isloyal is true
				retMe = retMe.concat("true\n");
			} else if (accounts[i] instanceof Savings && ((Savings) accounts[i]).getLoyal() == false) {
				retMe = retMe.concat("false\n");
			}

			if ( accounts[i] instanceof MoneyMarket) {
				retMe = retMe.concat(Integer.toString(((MoneyMarket) accounts[i]).getWith()) + "\n");
			}
		}

		return retMe;
	}
}