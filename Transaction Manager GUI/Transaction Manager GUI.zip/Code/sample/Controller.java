package sample;

/**
 * Controller class which acts as transaction manager. Here we create buttons, radio buttons, textfield, textarea, etc
 * to make the GUI functional
 * @author FERRIS HUSSEIN
 */

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.util.Scanner;

public class Controller {

    /**
     * Declare new account database
     */

    private AccountDatabase myAccounts = new AccountDatabase();

    /**
     * Declare buttons
     */

    @FXML
    private Button openAccount, closeAccount, deposit, withdraw, printAll, printLastName, printDate, importButton, exportButton, clearButton;

    /**
     * Declare RadioButton's
     */

    @FXML
    private RadioButton checking, savings, moneymarket, closeChecking, closeSaving, closeMoneyMarket, depChecking, depSavings, depMM, withChecking, withSavings, withMM;

    /**
     * Declare Checkbox's
     */

    @FXML
    private CheckBox isLoyal, isDirect;

    /**
     * Declare TextArea's
     */

    @FXML
    private TextArea output, outputOpen, outputClose, outputDep, outputWith;

    /**
     * Declare TextField
     */

    @FXML
    private TextField firstName, lastName, Balance, Date, fclose, lclose, depositFNAME, depositLNAME, depBalance, withFNAME, withLNAME, withBalance;

    /**
     * Declare ToggleGroup
     */

    @FXML
    private ToggleGroup accountType;

    /**
     * This method disables isLoyal Button when Checking is selected
     * @param event, checking buttonis selected
     */

    @FXML
    public void checkingSelected(ActionEvent event) {
        if (isDirect.isDisabled()) {
            isDirect.setDisable(false);
        }
        isLoyal.setSelected(false);
        isLoyal.setDisable(true);
    }

    /**
     * This method disables isDirect Button when Savings is selected
     * @param event, savings button is selected
     */

    @FXML
    public void savingsSelected(ActionEvent event) {
        if (isLoyal.isDisabled()) {
            isLoyal.setDisable(false);
        }
        isDirect.setSelected(false);
        isDirect.setDisable(true);
    }

    /**
     * This method disables isLoyal and isDirect Button's when MoneyMarket is selected
     * @param event, moneymarket Button is selected
     */

    @FXML
    public void mmSelected(ActionEvent event) {
        isLoyal.setSelected(false);
        isDirect.setSelected(false);

        isLoyal.setDisable(true);
        isDirect.setDisable(true);
    }

    /**
     * This method handles user inputs to open accounts and insert them into database.
     * Exceptions are caught on Input Data Type Mismatches. Output also appends error messages
     * such as invalid dates and already opened accounts
     * @param event, openAccount Button is clicked
     */

    @FXML
    public void openAccount(ActionEvent event)
    {
        try {
            if (firstName.getText().equals("") || lastName.getText().equals("") || Balance.getText().equals("") || Date.getText().equals("")) {
                throw new Exception();
            }

            if (checking.isSelected()) {
                Checking newCheck = new Checking();
                newCheck.setHolder(firstName.getText(),lastName.getText());
                newCheck.setBalance(Double.parseDouble(Balance.getText()));
                if (isDirect.isSelected()){
                    newCheck.setDirect(true);
                } else {
                    newCheck.setDirect(false);
                }
                boolean checkDate = newCheck.setDate(Date.getText());
                if (checkDate == true) {
                    boolean checkAdd = myAccounts.add(newCheck);
                    if (checkAdd == true) {
                        outputOpen.appendText("Account opened and added to the database.\n");
                    } else {
                        outputOpen.appendText("Account is already in the database.\n");
                    }
                } else {
                    outputOpen.appendText(newCheck.getDate().toString() + " is not a valid date!\n");
                }
            } else if (savings.isSelected()) {
                Savings newSave = new Savings();
                newSave.setHolder(firstName.getText(),lastName.getText());
                newSave.setBalance(Double.parseDouble(Balance.getText()));
                if (isLoyal.isSelected()){
                    newSave.setLoyal(true);
                } else {
                    newSave.setLoyal(false);
                }
                boolean checkDate = newSave.setDate(Date.getText());
                if (checkDate == true) {
                    boolean checkAdd = myAccounts.add(newSave);
                    if (checkAdd == true) {
                        outputOpen.appendText("Account opened and added to the database.\n");
                    } else {
                        outputOpen.appendText("Account is already in the database.\n");
                    }
                } else {
                    outputOpen.appendText(newSave.getDate().toString() + " is not a valid date!\n");
                }
            } else if (moneymarket.isSelected()) {
                MoneyMarket newMM = new MoneyMarket();
                newMM.setHolder(firstName.getText(),lastName.getText());
                newMM.setBalance(Double.parseDouble(Balance.getText()));
                boolean checkDate = newMM.setDate(Date.getText());
                if (checkDate == true) {
                    boolean checkAdd = myAccounts.add(newMM);
                    if (checkAdd == true) {
                        outputOpen.appendText("Account opened and added to the database.\n");
                    } else {
                        outputOpen.appendText("Account is already in the database.\n");
                    }
                } else {
                    outputOpen.appendText(newMM.getDate().toString() + " is not a valid date!\n");
                }
            }
        } catch (Exception e) {
            outputOpen.appendText("Input data type mismatch.\n");
        }
    }

    /**
     * This method handles user input to close account and removes them from database.
     * Exceptions are caught on Input Data Type Mismatches. Output also appends error messages
     * such as nonexistent accounts.
     * @param event, closeAccount button is selected
     */

    @FXML
    public void closeAccount(ActionEvent event)
    {
        try {
            if (fclose.getText().equals("") || lclose.getText().equals("")) {
                throw new Exception();
            }

            if (closeChecking.isSelected()) {
                Checking remCheck = new Checking();
                remCheck.setHolder(fclose.getText(),lclose.getText());
                boolean checkRem = myAccounts.remove(remCheck);
                if (checkRem == true) {
                    outputClose.appendText("Account closed and removed from the database.\n");
                } else {
                    outputClose.appendText("Account does not exist.\n");
                }
            } else if (closeSaving.isSelected()) {
                Savings remSaving = new Savings();
                remSaving.setHolder(fclose.getText(),lclose.getText());
                boolean savingRem = myAccounts.remove(remSaving);
                if (savingRem == true) {
                    outputClose.appendText("Account closed and removed from the database.\n");
                } else {
                    outputClose.appendText("Account does not exist.\n");
                }
            } else if (closeMoneyMarket.isSelected()) {
                MoneyMarket remMM = new MoneyMarket();
                remMM.setHolder(fclose.getText(),lclose.getText());
                boolean mmRem = myAccounts.remove(remMM);
                if (mmRem == true) {
                    outputClose.appendText("Account closed and removed from the database.\n");
                } else {
                    outputClose.appendText("Account does not exist.\n");
                }
            }
        } catch (Exception e) {
            outputClose.appendText("Input data type mismatch.\n");
        }
    }

    /**
     * This method handles user input to deposit to an account in the database.
     * Exceptions are caught on Input Data Type Mismatches. Output also appends error messages
     * such as nonexistent accounts.
     * @param event, deposit button is selected
     */

    @FXML
    public void deposit(ActionEvent event)
    {
        try {
            if (depositFNAME.getText().equals("") || depositLNAME.getText().equals("") || depBalance.getText().equals("")) {
                throw new Exception();
            }

            if (depChecking.isSelected()) {
                Checking depCheck = new Checking();
                depCheck.setHolder(depositFNAME.getText(),depositLNAME.getText());
                boolean checkDep = myAccounts.deposit(depCheck, Double.parseDouble(depBalance.getText()));
                if (checkDep == true) {
                    outputDep.appendText(Double.parseDouble(depBalance.getText()) + " deposited to account\n");
                } else {
                    outputDep.appendText("Account does not exist.\n");
                }
            } else if (depSavings.isSelected()) {
                Savings depSave = new Savings();
                depSave.setHolder(depositFNAME.getText(),depositLNAME.getText());
                boolean saveDep = myAccounts.deposit(depSave, Double.parseDouble(depBalance.getText()));
                if (saveDep == true) {
                    outputDep.appendText(Double.parseDouble(depBalance.getText()) + " deposited to account\n");
                } else {
                    outputDep.appendText("Account does not exist.\n");
                }
            } else if (depMM.isSelected()) {
                MoneyMarket depMM = new MoneyMarket();
                depMM.setHolder(depositFNAME.getText(),depositLNAME.getText());
                boolean mmDep = myAccounts.deposit(depMM, Double.parseDouble(depBalance.getText()));
                if (mmDep == true) {
                    outputDep.appendText(Double.parseDouble(depBalance.getText()) + " deposited to account\n");
                } else {
                    outputDep.appendText("Account does not exist.\n");
                }
            }
        } catch (Exception e) {
            outputDep.appendText("Input data type mismatch.\n");
        }
    }

    /**
     * This method handles user input to withdraw from an account in the database.
     * Exceptions are caught on Input Data Type Mismatches. Output also appends error messages
     * such as nonexistent accounts and insufficient funds.
     * @param event, deposit button is selected
     */

    @FXML
    public void withdraw(ActionEvent event)
    {
        try {
            if (withFNAME.getText().equals("") || withLNAME.getText().equals("") || withBalance.getText().equals("")) {
                throw new Exception();
            }

            if (withChecking.isSelected()) {
                Checking withCheck = new Checking();
                withCheck.setHolder(withFNAME.getText(),withLNAME.getText());
                boolean checkWith = myAccounts.debitHelp(withCheck, Double.parseDouble(withBalance.getText()));
                if (checkWith == true) {
                    outputWith.appendText(Double.parseDouble(withBalance.getText()) + " withdrawn from account\n");
                } else {
                    outputWith.appendText("Insufficient Funds.\n");
                }
            } else if (withSavings.isSelected()) {
                Savings withSave = new Savings();
                withSave.setHolder(withFNAME.getText(),withLNAME.getText());
                boolean saveWith = myAccounts.debitHelp(withSave, Double.parseDouble(withBalance.getText()));
                if (saveWith == true) {
                    outputWith.appendText(Double.parseDouble(withBalance.getText()) + " withdrawn from account\n");
                } else {
                    outputWith.appendText("Insufficient Funds.\n");
                }
            } else if (withMM.isSelected()) {
                MoneyMarket withMM = new MoneyMarket();
                withMM.setHolder(withFNAME.getText(),withLNAME.getText());
                int mmWith = myAccounts.withdrawal(withMM, Double.parseDouble(withBalance.getText()));
                if (mmWith == 0) {
                    outputWith.appendText(Double.parseDouble(withBalance.getText()) + " withdrawn from account\n");
                } else if (mmWith == 1) {
                    outputWith.appendText("Insufficient Funds.\n");
                } else {
                    outputWith.appendText("Account does not exist.\n");
                }
            }
        } catch (Exception e) {
            outputWith.appendText("Input data type mismatch.\n");
        }
    }

    /**
     * This method invokes the printAccounts function in AccountDatabase.java and appends
     * returned String to output
     * @param event, printAll button is selected
     */

    @FXML
    public void printAll(ActionEvent event)
    {
        output.appendText(myAccounts.printAccounts());
    }

    /**
     * This method invokes the printByDateOpen function in AccountDatabase.java and appends
     * returned String to output
     * @param event, printDate button is selected
     */

    @FXML
    public void printByDate(ActionEvent event)
    {
        output.appendText(myAccounts.printByDateOpen());
    }

    /**
     * This method invokes the printByLastName function in AccountDatabase.java and appends
     * returned String to ouput
     * @param event, printLastName button is selected
     */

    @FXML
    public void printByLastName(ActionEvent event) { output.appendText(myAccounts.printByLastName()); }

    /**
     * This method allows output field to be cleared
     * @param event, clearButton is pressed
     */

    @FXML
    public void clearPrint(ActionEvent event) { output.clear();}

    /**
     * This method allows a user to import a .txt file that contains accounts to be added to database.
     * While loop reads input file line by line
     * @param event, import Button selected
     * @throws FileNotFoundException
     */

    @FXML
    public void importFile(ActionEvent event) throws FileNotFoundException {
        FileChooser fileLoader = new FileChooser();
        fileLoader.setTitle("Open File");
        fileLoader.getExtensionFilters().add(new FileChooser.ExtensionFilter("TXT FILES","*.txt"));
        fileLoader.getExtensionFilters().add(new FileChooser.ExtensionFilter("ALL FILES","*.*"));
        File myFile = fileLoader.showOpenDialog(new Stage());

        try {
            Scanner sc = new Scanner(myFile);
            while (sc.hasNextLine()) {
                myAccounts.importFileAccounts(sc.nextLine());
            }
        } catch (Exception e) {
            // no file selected
        }

    }

    /**
     * This method allows a user to export a .txt file of current accounts in database
     * @param event, exportButton is selected
     */

    @FXML
    public void exportFile(ActionEvent event) {
        FileChooser fileLoader = new FileChooser();
        fileLoader.setTitle("Save File");
        fileLoader.getExtensionFilters().add(new FileChooser.ExtensionFilter("TXT FILES","*.txt"));
        fileLoader.getExtensionFilters().add(new FileChooser.ExtensionFilter("ALL FILES","*.*"));
        File myFile = fileLoader.showSaveDialog(new Stage());

        try {
            FileWriter writer = new FileWriter(myFile);
            writer.write(myAccounts.exportFileAccounts());
            writer.close();
        } catch (Exception e) {
            // save file not created
        }
    }


}

